package uz.anorbank.anorbank_zadaniya_log_etries_saver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnorbankZadaniyaLogEtriesSaverApplicationTests {

    @Test
    void contextLoads() {
    }

}
