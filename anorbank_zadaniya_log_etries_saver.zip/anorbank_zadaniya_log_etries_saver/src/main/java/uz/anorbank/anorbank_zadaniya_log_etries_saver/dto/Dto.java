package uz.anorbank.anorbank_zadaniya_log_etries_saver.dto;

public interface Dto {
}
