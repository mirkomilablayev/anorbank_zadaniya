package uz.anorbank.anorbank_zadaniya_log_etries_saver.dto.odometerHistory;

import uz.anorbank.anorbank_zadaniya_log_etries_saver.dto.Dto;

public class OdometerHistoryUpdateDto  implements Dto {
}
