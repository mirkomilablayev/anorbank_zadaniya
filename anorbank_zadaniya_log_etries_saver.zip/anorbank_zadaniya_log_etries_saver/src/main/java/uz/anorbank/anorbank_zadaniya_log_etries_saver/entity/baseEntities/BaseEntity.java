package uz.anorbank.anorbank_zadaniya_log_etries_saver.entity.baseEntities;

public interface BaseEntity {
}
