package uz.anorbank.anorbank_zadaniya_log_etries_saver.service;

public interface BaseService {
}
