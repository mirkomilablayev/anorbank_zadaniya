package uz.anorbank.anorbank_zadaniya_log_etries_saver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnorbankZadaniyaLogEtriesSaverApplication {

    public static void main(String[] args) {
        SpringApplication.run(AnorbankZadaniyaLogEtriesSaverApplication.class, args);
    }

}
