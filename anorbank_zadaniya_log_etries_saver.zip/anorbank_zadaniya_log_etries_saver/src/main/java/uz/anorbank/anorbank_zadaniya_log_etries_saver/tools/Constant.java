package uz.anorbank.anorbank_zadaniya_log_etries_saver.tools;

public interface Constant {
    String ADMIN = "ADMIN";
    String USER = "USER";
    String DRIVER = "DRIVER";

//    String filePaths = "D:\\rasmlar";
    String filePaths = "/home/mirkomil/ProfilePictures";


}
