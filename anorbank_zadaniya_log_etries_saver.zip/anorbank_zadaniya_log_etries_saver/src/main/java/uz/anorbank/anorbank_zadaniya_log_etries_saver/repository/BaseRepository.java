package uz.anorbank.anorbank_zadaniya_log_etries_saver.repository;

public interface BaseRepository {
}
